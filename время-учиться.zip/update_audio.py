import sys

with open("app/src/main/java/com/example/logic/FocusViewModel.kt", "r") as f:
    content = f.read()

old_audio = """    private fun playUnlockSound(context: Context) {
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            val ringtone = android.media.RingtoneManager.getRingtone(context, uri)
            ringtone?.play()
            kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                kotlinx.coroutines.delay(5000)
                ringtone?.stop()
            }
        } catch (e: Exception) {}
    }"""

new_audio = """    private fun playUnlockSound(context: Context) {
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            val mediaPlayer = android.media.MediaPlayer.create(context, uri)
            mediaPlayer?.setOnCompletionListener {
                it.release()
            }
            mediaPlayer?.start()
            
            kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                kotlinx.coroutines.delay(5000)
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer.stop()
                }
                mediaPlayer?.release()
            }
        } catch (e: Exception) {}
    }"""

content = content.replace(old_audio, new_audio)

with open("app/src/main/java/com/example/logic/FocusViewModel.kt", "w") as f:
    f.write(content)

