import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if line.strip() == "import RoundedCornerShape": continue
    if line.strip() == "import CircleShape": continue
    line = line.replace(".androidx.compose.foundation.shape.clip", ".clip")
    new_lines.append(line)

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.writelines(new_lines)

