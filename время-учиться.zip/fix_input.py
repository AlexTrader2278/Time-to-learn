import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

# 1
content = content.replace(
"    var selectedDuration by remember { mutableStateOf(30) }\n    val durations = listOf(15, 30, 60, 90)",
"    var selectedDuration by remember { mutableStateOf(30) }\n    var customDurationInput by remember { mutableStateOf(\"\") }\n    val durations = listOf(15, 30, 60, 90)"
)

# 2
content = content.replace(
"""                        Card(
                            onClick = { selectedDuration = duration },""",
"""                        Card(
                            onClick = { 
                                selectedDuration = duration
                                customDurationInput = "" 
                            },"""
)

# 3
new_input = """                }
                
                OutlinedTextField(
                    value = customDurationInput,
                    onValueChange = { input -> 
                        if (input.isEmpty()) {
                            customDurationInput = ""
                        } else if (input.all { it.isDigit() }) {
                            val intVal = input.toIntOrNull() ?: 0
                            if (intVal <= 1440) {
                                customDurationInput = input
                                if (intVal > 0) {
                                    selectedDuration = intVal
                                }
                            }
                        }
                    },
                    label = { Text("Ввести время вручную (в минутах)", color = com.example.ui.theme.BrandTextMuted) },
                    placeholder = { Text("Например: 120 (макс 1440)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = com.example.ui.theme.BrandBlue,
                        unfocusedBorderColor = com.example.ui.theme.BrandSurface,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = com.example.ui.theme.BrandSurface
                    )
                )

                Card("""

content = content.replace("                }\n\n                Card(", new_input)

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(content)
