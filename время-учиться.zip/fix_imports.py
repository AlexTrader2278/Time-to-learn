import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if line.startswith("import androidx.compose.foundation.shape.RoundedCornerShape"): continue
    if line.startswith("import androidx.compose.ui.layout.ContentScale"): continue
    if line.startswith("import androidx.compose.foundation.shape.CircleShape"): continue
    if line.startswith("import androidx.compose.ui.draw.clip"): continue
    if line.startswith("import Modifier.clip"): continue
    
    # Fix the weird Modifier.Modifier.clip or .androidx.compose.ui.draw.clip
    line = line.replace(".Modifier.clip", ".clip")
    line = line.replace(".androidx.compose.ui.draw.clip", ".clip")
    
    new_lines.append(line)

imports = """
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
"""

# Insert imports after the package declaration
for i, line in enumerate(new_lines):
    if line.startswith("import androidx.compose.ui.platform.LocalContext"):
        new_lines.insert(i, imports)
        break

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.writelines(new_lines)

