import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

content = content.replace("@Composable\n@Composable\nfun SetupScreen", "@Composable\nfun SetupScreen")
content = content.replace("fun SettingsScreen(", "@Composable\nfun SettingsScreen(")

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(content)
