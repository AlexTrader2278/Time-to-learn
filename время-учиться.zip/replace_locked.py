import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

# Find LockedScreen
locked_idx = content.find("fun LockedScreen")
col_start = content.find("    Column(", locked_idx)
col_end = content.find("    if (showForgotPinDialog)", col_start)

replacement = """    Surface(
        modifier = Modifier.fillMaxSize(),
        color = com.example.ui.theme.BrandDarkBlue
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 48.dp)
            ) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = "Locked",
                    tint = com.example.ui.theme.BrandSurface,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Телефон заблокирован",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.BrandSurface
                    )
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Время учиться!",
                    style = MaterialTheme.typography.titleMedium,
                    color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.8f)
                )
            }

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(280.dp)) {
                androidx.compose.material3.CircularProgressIndicator(
                    progress = { 1f },
                    modifier = Modifier.fillMaxSize(),
                    color = com.example.ui.theme.BrandBlue.copy(alpha = 0.3f),
                    strokeWidth = 12.dp,
                    trackColor = androidx.compose.ui.graphics.Color.Transparent
                )
                // Fake animated progress
                val infiniteTransition = rememberInfiniteTransition()
                val animatedProgress by infiniteTransition.animateFloat(
                    initialValue = 0.8f,
                    targetValue = 0.85f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
                androidx.compose.material3.CircularProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxSize(),
                    color = com.example.ui.theme.BrandBlue,
                    strokeWidth = 12.dp,
                    strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
                    trackColor = androidx.compose.ui.graphics.Color.Transparent
                )
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 64.sp,
                            color = com.example.ui.theme.BrandSurface
                        )
                    )
                    Text(
                        text = "осталось",
                        style = MaterialTheme.typography.bodyLarge,
                        color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.7f)
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(bottom = 24.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandBlue.copy(alpha = 0.2f)),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Filled.Star,
                            contentDescription = "Star",
                            tint = com.example.ui.theme.BrandLightBg,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Ты справишься!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandSurface)
                            Text("Каждая минута приближает\nк твоей цели.", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.8f))
                        }
                    }
                }
                
                TextButton(onClick = { 
                    viewModel.clearPinError()
                    showUnlockDialog = true 
                }) {
                    Text("Досрочно разблокировать", color = com.example.ui.theme.BrandSurface.copy(alpha = 0.5f))
                }
                TextButton(onClick = { showForgotPinDialog = true }) {
                    Text("Забыли PIN-код?", color = com.example.ui.theme.BrandSurface.copy(alpha = 0.3f))
                }
            }
        }
    }

"""

new_content = content[:col_start] + replacement + content[col_end:]

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(new_content)

