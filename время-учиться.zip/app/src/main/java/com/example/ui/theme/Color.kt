package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MarusyaBlue = Color(0xFF1976D2)
val MarusyaDarkBlue = Color(0xFF0D47A1)
val MarusyaLightBlue = Color(0xFFBBDEFB)
val MarusyaAccent = Color(0xFFFFC107)

val Blue80 = Color(0xFF90CAF9)
val BlueGrey80 = Color(0xFFB0BEC5)
val SkyBlue80 = Color(0xFFB3E5FC)

val Blue40 = Color(0xFF1976D2)
val BlueGrey40 = Color(0xFF455A64)
val SkyBlue40 = Color(0xFF03A9F4)

// ChatGPT Mockup Colors
val BrandBlue = Color(0xFF1E88E5)
val BrandDarkBlue = Color(0xFF0D1F3C)
val BrandLightBg = Color(0xFFF0F4F8)
val BrandSurface = Color(0xFFFFFFFF)
val BrandTextDark = Color(0xFF1E293B)
val BrandTextMuted = Color(0xFF64748B)
val BrandAccentYellow = Color(0xFFFFC107)
