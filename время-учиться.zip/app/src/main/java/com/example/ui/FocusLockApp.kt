package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.MainActivity
import com.example.logic.FocusUiState
import com.example.logic.FocusViewModel
import com.example.data.FocusSession
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FocusLockApp(viewModel: FocusViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val activity = LocalActivity.current ?: return
    val context = LocalContext.current

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        AnimatedContent(
            targetState = uiState,
            transitionSpec = {
                fadeIn(animationSpec = tween(500)) togetherWith fadeOut(animationSpec = tween(500))
            },
            label = "ScreenTransition"
        ) { state ->
            when (state) {
                is FocusUiState.Splash -> SplashScreen()
                is FocusUiState.Setup -> SetupScreen(
                    viewModel = viewModel,
                    onStart = { duration -> viewModel.startFocus(duration, context) },
                    onGoToSettings = { viewModel.goToSetupPin() },
                    hasPin = !settings?.pin.isNullOrEmpty()
                )
                is FocusUiState.Locked -> LockedScreen(
                    viewModel = viewModel,
                    onUnlockRequested = { pin -> viewModel.verifyPinAndUnlock(pin, context) }
                )
                is FocusUiState.SetupPIN -> SettingsScreen(
                    currentPin = settings?.pin,
                    currentThemeIsDark = settings?.isDarkTheme,
                    onSavePin = { pin, answer -> viewModel.savePin(pin, answer) },
                    onThemeChange = { isDark -> viewModel.setTheme(isDark) },
                    onCancel = { viewModel.cancelSetupPin() }
                )
            }
        }
    }
}

@Composable
fun SplashScreen() {
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(1000, easing = LinearOutSlowInEasing)
        )
    }
    val infiniteTransition = rememberInfiniteTransition(label = "SplashAnimation")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScaleAnimation"
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(alpha = alpha.value),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
                contentDescription = null,
                modifier = Modifier
                    .size(240.dp)
                    .graphicsLayer(scaleX = scale, scaleY = scale)
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Время Учиться",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 2.sp
                )
            )
        }
    }
}

@Composable
fun SettingsScreen(
    currentPin: String?, 
    currentThemeIsDark: Boolean?, 
    onSavePin: (String, String) -> Unit, 
    onThemeChange: (Boolean?) -> Unit, 
    onCancel: () -> Unit
) {
    BackHandler {
        onCancel()
    }
    
    var pinInput by remember { mutableStateOf(currentPin ?: "") }
    var answerInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .systemBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text("Настройки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            
            OutlinedTextField(
                value = pinInput,
                onValueChange = { if (it.length <= 4 && it.all { char -> char.isDigit() }) pinInput = it },
                label = { Text("PIN-код (4 цифры)") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            
            OutlinedTextField(
                value = answerInput,
                onValueChange = { answerInput = it },
                label = { Text("Секретное слово для восстановления (обязательно)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Оформление (Тема)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onThemeChange(null) }) {
                        RadioButton(selected = currentThemeIsDark == null, onClick = { onThemeChange(null) })
                        Text("Авто")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onThemeChange(false) }) {
                        RadioButton(selected = currentThemeIsDark == false, onClick = { onThemeChange(false) })
                        Text("Светлая")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onThemeChange(true) }) {
                        RadioButton(selected = currentThemeIsDark == true, onClick = { onThemeChange(true) })
                        Text("Тёмная")
                    }
                }
            }
            
            if (errorMsg.isNotEmpty()) {
                Text(errorMsg, color = MaterialTheme.colorScheme.error)
            }
            
            Spacer(Modifier.weight(1f))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onCancel) {
                    Text("Отмена")
                }
                Button(
                    onClick = {
                        if (pinInput.length != 4) {
                            errorMsg = "PIN-код должен состоять из 4 цифр"
                        } else if (answerInput.isBlank()) {
                            errorMsg = "Укажите секретное слово"
                        } else {
                            onSavePin(pinInput, answerInput)
                        }
                    }
                ) {
                    Text("Сохранить")
                }
            }
        }
    }
}


@Composable
fun SetupScreen(viewModel: FocusViewModel, onStart: (Int) -> Unit, onGoToSettings: () -> Unit, hasPin: Boolean) {
    var currentTab by remember { mutableStateOf("home") }
    val sessions by viewModel.sessions.collectAsState()
    val context = LocalContext.current
    var lifecycleEvent by remember { mutableStateOf(androidx.lifecycle.Lifecycle.Event.ON_ANY) }
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> lifecycleEvent = event }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val hasOverlayPermission = remember(lifecycleEvent) { android.provider.Settings.canDrawOverlays(context) }
    val hasNotificationPermission = remember(lifecycleEvent) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else true
    }
    val hasAllPermissions = hasOverlayPermission && hasNotificationPermission
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
        onResult = { }
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == "home",
                    onClick = { currentTab = "home" },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Главная") },
                    label = { Text("Главная", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = com.example.ui.theme.BrandBlue, selectedTextColor = com.example.ui.theme.BrandBlue, indicatorColor = com.example.ui.theme.BrandLightBg)
                )
                NavigationBarItem(
                    selected = currentTab == "stats",
                    onClick = { currentTab = "stats" },
                    icon = { Icon(Icons.Default.BarChart, contentDescription = "Статистика") },
                    label = { Text("Статистика", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(unselectedIconColor = com.example.ui.theme.BrandTextMuted, unselectedTextColor = com.example.ui.theme.BrandTextMuted)
                )
                NavigationBarItem(
                    selected = currentTab == "achievements",
                    onClick = { currentTab = "achievements" },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Достижения") },
                    label = { Text("Достижения", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(unselectedIconColor = com.example.ui.theme.BrandTextMuted, unselectedTextColor = com.example.ui.theme.BrandTextMuted)
                )
                NavigationBarItem(
                    selected = currentTab == "profile",
                    onClick = { currentTab = "profile" },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Профиль") },
                    label = { Text("Профиль", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(unselectedIconColor = com.example.ui.theme.BrandTextMuted, unselectedTextColor = com.example.ui.theme.BrandTextMuted)
                )
            }
        }
    ) { paddingValues ->
        Surface(
            modifier = Modifier.fillMaxSize().padding(paddingValues),
            color = com.example.ui.theme.BrandLightBg
        ) {
            when (currentTab) {
                "home" -> HomeContent(onStart = onStart, onGoToSettings = onGoToSettings, hasPin = hasPin,
                    hasAllPermissions = hasAllPermissions, hasOverlayPermission = hasOverlayPermission, hasNotificationPermission = hasNotificationPermission,
                    permissionLauncher = permissionLauncher, context = context
                )
                "stats" -> StatisticsContent(sessions = sessions)
                "achievements" -> AchievementsContent(sessions = sessions)
                "profile" -> ProfileContent(onGoToSettings = onGoToSettings, sessions = sessions)
            }
        }
    }
}

@Composable
fun HomeContent(
    onStart: (Int) -> Unit, 
    onGoToSettings: () -> Unit, 
    hasPin: Boolean,
    hasAllPermissions: Boolean,
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    permissionLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    context: android.content.Context
) {
    var selectedDuration by remember { mutableStateOf(30) }
    var customDurationInput by remember { mutableStateOf("") }
    val durations = listOf(15, 30, 60, 90)
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 24.dp).padding(top = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
                    contentDescription = "Avatar",
                    modifier = Modifier.size(48.dp).clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = "Время Учиться",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = com.example.ui.theme.BrandTextDark
                )
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Сегодня ты можешь больше!",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.BrandBlue,
                            lineHeight = 28.sp
                        )
                    )
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Star",
                        tint = com.example.ui.theme.BrandAccentYellow,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            if (!hasAllPermissions) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Требуются разрешения", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.titleMedium)
                        Text("Для надежной работы блокировки необходимо выдать разрешения:", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        if (!hasOverlayPermission) {
                            Button(
                                onClick = { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${context.packageName}"))) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onErrorContainer, contentColor = MaterialTheme.colorScheme.errorContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Разрешить поверх окон") }
                        }
                        if (!hasNotificationPermission) {
                            Button(
                                onClick = { if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) { permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS) } },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onErrorContainer, contentColor = MaterialTheme.colorScheme.errorContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Разрешить уведомления") }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    durations.forEach { duration ->
                        val isSelected = selectedDuration == duration
                        Card(
                            onClick = { 
                                selectedDuration = duration
                                customDurationInput = "" 
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) com.example.ui.theme.BrandBlue else com.example.ui.theme.BrandSurface
                            ),
                            shape = RoundedCornerShape(20.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 0.dp),
                            modifier = Modifier.size(76.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = duration.toString(),
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSelected) com.example.ui.theme.BrandSurface else com.example.ui.theme.BrandTextDark
                                )
                                Text(
                                    text = "мин",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isSelected) com.example.ui.theme.BrandLightBg else com.example.ui.theme.BrandTextMuted
                                )
                            }
                        }
                    }
                }
                
                OutlinedTextField(
                    value = customDurationInput,
                    onValueChange = { input -> 
                        if (input.isEmpty()) {
                            customDurationInput = ""
                        } else if (input.all { it.isDigit() }) {
                            val intVal = input.toIntOrNull() ?: 0
                            if (intVal <= 1440) {
                                customDurationInput = input
                                if (intVal > 0) {
                                    selectedDuration = intVal
                                }
                            }
                        }
                    },
                    label = { Text("Ввести время вручную (в минутах)", color = com.example.ui.theme.BrandTextMuted) },
                    placeholder = { Text("Например: 120 (макс 1440)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = com.example.ui.theme.BrandBlue,
                        unfocusedBorderColor = com.example.ui.theme.BrandSurface,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = com.example.ui.theme.BrandSurface
                    )
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(com.example.ui.theme.BrandLightBg), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Timer, contentDescription = "Time", tint = com.example.ui.theme.BrandBlue)
                            }
                            Spacer(Modifier.width(16.dp))
                            Column {
                                Text("Выбранное время", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted)
                                Text("$selectedDuration минут", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                            }
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Custom", tint = com.example.ui.theme.BrandTextMuted)
                    }
                }

                Button(
                    onClick = { onStart(selectedDuration) },
                    modifier = Modifier.fillMaxWidth().height(68.dp),
                    enabled = hasPin && selectedDuration > 0,
                    shape = RoundedCornerShape(34.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.BrandBlue)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Заблокировать телефон", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                if (!hasPin) {
                    Text(
                        text = "Сначала установите PIN-код в настройках (Профиль)",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }

                Box(
                    modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(24.dp)).background(com.example.ui.theme.BrandLightBg.copy(alpha = 0.5f))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val path = Path()
                        path.moveTo(0f, size.height)
                        path.lineTo(size.width * 0.3f, size.height * 0.4f)
                        path.lineTo(size.width * 0.6f, size.height * 0.8f)
                        path.lineTo(size.width, size.height * 0.2f)
                        path.lineTo(size.width, size.height)
                        path.close()
                        drawPath(path, color = com.example.ui.theme.BrandBlue.copy(alpha = 0.1f))
                        
                        val path2 = Path()
                        path2.moveTo(0f, size.height)
                        path2.lineTo(size.width * 0.4f, size.height * 0.6f)
                        path2.lineTo(size.width * 0.8f, size.height * 0.9f)
                        path2.lineTo(size.width, size.height * 0.5f)
                        path2.lineTo(size.width, size.height)
                        path2.close()
                        drawPath(path2, color = com.example.ui.theme.BrandBlue.copy(alpha = 0.15f))
                    }
                    Row(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(com.example.ui.theme.BrandSurface), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Flag, contentDescription = "Goal", tint = com.example.ui.theme.BrandBlue)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Помни!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                            Text("Сейчас ты делаешь важное дело. Ты можешь!", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted, lineHeight = 20.sp)
                        }
                    }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}
@Composable
fun LockedScreen(viewModel: FocusViewModel, onUnlockRequested: (String) -> Unit) {
    val activity = LocalActivity.current
    val window = activity?.window
    LaunchedEffect(Unit) {
        try { activity?.startLockTask() } catch (e: Exception) {}
        window?.let {
            WindowCompat.setDecorFitsSystemWindows(it, false)
            WindowInsetsControllerCompat(it, it.decorView).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            try { activity?.stopLockTask() } catch (e: Exception) {}
            window?.let {
                WindowCompat.setDecorFitsSystemWindows(it, true)
                WindowInsetsControllerCompat(it, it.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    BackHandler(enabled = true) {}
    
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    var showUnlockDialog by remember { mutableStateOf(false) }
    var showForgotPinDialog by remember { mutableStateOf(false) }

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val timeStr = String.format("%02d:%02d", minutes, seconds)

    val infiniteTransition = rememberInfiniteTransition()
    val animatedGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f, targetValue = 1.0f,
        animationSpec = infiniteRepeatable(animation = tween(1500, easing = LinearEasing), repeatMode = RepeatMode.Reverse)
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Starry Night Background
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0D1F3C), Color(0xFF1B3B6F))))
            
            // Draw stars
            val rand = java.util.Random(42)
            for (i in 0..50) {
                val x = rand.nextFloat() * size.width
                val y = rand.nextFloat() * (size.height * 0.7f)
                val radius = rand.nextFloat() * 3f + 1f
                drawCircle(color = Color.White.copy(alpha = rand.nextFloat() * 0.5f + 0.1f), radius = radius, center = Offset(x, y))
            }
            
            // Draw mountains at bottom
            val path = Path()
            path.moveTo(0f, size.height)
            path.lineTo(0f, size.height * 0.75f)
            path.lineTo(size.width * 0.2f, size.height * 0.65f)
            path.lineTo(size.width * 0.45f, size.height * 0.8f)
            path.lineTo(size.width * 0.7f, size.height * 0.6f)
            path.lineTo(size.width, size.height * 0.75f)
            path.lineTo(size.width, size.height)
            path.close()
            drawPath(path, Brush.verticalGradient(listOf(Color(0xFF1E3A5F), Color(0xFF0D1F3C)), startY = size.height * 0.5f, endY = size.height))
            
            val path2 = Path()
            path2.moveTo(0f, size.height)
            path2.lineTo(size.width * 0.3f, size.height * 0.8f)
            path2.lineTo(size.width * 0.6f, size.height * 0.68f)
            path2.lineTo(size.width * 0.85f, size.height * 0.85f)
            path2.lineTo(size.width, size.height * 0.7f)
            path2.lineTo(size.width, size.height)
            path2.close()
            drawPath(path2, Brush.verticalGradient(listOf(Color(0xFF264A7F), Color(0xFF1E3A5F)), startY = size.height * 0.6f, endY = size.height))
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 24.dp)) {
                Icon(Icons.Default.Lock, contentDescription = "Locked", tint = com.example.ui.theme.BrandSurface, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(16.dp))
                Text(text = "Телефон заблокирован", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandSurface))
                Spacer(Modifier.height(8.dp))
                Text(text = "Время учиться!", style = MaterialTheme.typography.titleMedium, color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.8f))
            }

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(320.dp)) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = com.example.ui.theme.BrandBlue.copy(alpha = 0.2f * animatedGlow), radius = size.width / 2)
                    drawCircle(color = com.example.ui.theme.BrandBlue.copy(alpha = 0.4f), radius = size.width / 2.2f)
                    drawArc(
                        color = Color(0xFF00E5FF),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = 24f, cap = StrokeCap.Round),
                        size = androidx.compose.ui.geometry.Size(size.width / 1.1f, size.height / 1.1f),
                        topLeft = Offset(size.width * 0.045f, size.height * 0.045f)
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = timeStr, style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black, fontSize = 72.sp, color = com.example.ui.theme.BrandSurface))
                    Text(text = "осталось", style = MaterialTheme.typography.titleMedium, color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.8f))
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandBlue.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = "Star", tint = com.example.ui.theme.BrandSurface, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(20.dp))
                        Column {
                            Text("Ты справишься!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandSurface)
                            Text("Каждая минута приближает к твоей цели.", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandLightBg.copy(alpha = 0.9f))
                        }
                    }
                }
                
                TextButton(onClick = { viewModel.clearPinError(); showUnlockDialog = true }) {
                    Text("Досрочно разблокировать", color = com.example.ui.theme.BrandSurface.copy(alpha = 0.6f))
                }
            }
        }
    }

    if (showUnlockDialog) {
        var pinInput by remember { mutableStateOf("") }
        val pinError by viewModel.pinError.collectAsState()
        AlertDialog(
            onDismissRequest = { showUnlockDialog = false },
            title = { Text("Ввод PIN-кода") },
            text = {
                Column {
                    Text("Введите PIN-код для досрочной разблокировки:")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it.take(4) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        isError = pinError != null,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError != null) {
                        Text(pinError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(16.dp))
                    TextButton(
                        onClick = { 
                            showUnlockDialog = false
                            showForgotPinDialog = true
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Забыли PIN-код?")
                    }
                }
            },
            confirmButton = {
                Button(onClick = { onUnlockRequested(pinInput) }) { Text("Разблокировать") }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockDialog = false; viewModel.clearPinError() }) { Text("Отмена") }
            }
        )
    }

    if (showForgotPinDialog) {
        var answerInput by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf("") }
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showForgotPinDialog = false },
            title = { Text("Восстановление доступа") },
            text = {
                Column {
                    Text("Введите секретное слово, которое вы задали при установке PIN-кода:")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = answerInput,
                        onValueChange = { answerInput = it; errorMsg = "" },
                        isError = errorMsg.isNotEmpty(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (errorMsg.isNotEmpty()) {
                        Text(errorMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.verifySecurityAnswer(answerInput, context) { success ->
                        if (success) {
                            showForgotPinDialog = false
                            viewModel.stopFocus(context)
                        } else {
                            errorMsg = "Неверное слово"
                        }
                    }
                }) { Text("Подтвердить") }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPinDialog = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
fun StatisticsContent(sessions: List<com.example.data.FocusSession>) {
    val totalMinutes = sessions.sumOf { it.durationMinutes }
    val sessionCount = sessions.size
    
    val today = java.util.Calendar.getInstance()
    today.set(java.util.Calendar.HOUR_OF_DAY, 0)
    today.set(java.util.Calendar.MINUTE, 0)
    today.set(java.util.Calendar.SECOND, 0)
    today.set(java.util.Calendar.MILLISECOND, 0)
    val todayMillis = today.timeInMillis
    
    val todayMins = sessions.filter { it.timestampMillis >= todayMillis }.sumOf { it.durationMinutes }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text("Статистика", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark, modifier = Modifier.padding(top=16.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandBlue),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = com.example.ui.theme.BrandSurface)
                    Spacer(Modifier.height(12.dp))
                    Text(text = "$totalMinutes мин", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandSurface)
                    Text(text = "Всего времени", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandLightBg)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Icon(Icons.Default.BarChart, contentDescription = null, tint = com.example.ui.theme.BrandBlue)
                    Spacer(Modifier.height(12.dp))
                    Text(text = "$sessionCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                    Text(text = "Сессий", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted)
                }
            }
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Сегодня", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "$todayMins мин", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black, color = com.example.ui.theme.BrandBlue)
                    Spacer(Modifier.width(16.dp))
                    Text("отличная работа!", style = MaterialTheme.typography.bodyLarge, color = com.example.ui.theme.BrandTextMuted)
                }
            }
        }
        
        if (sessions.isNotEmpty()) {
            Text("История", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
            sessions.take(10).forEach { session ->
                val date = java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(session.timestampMillis))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(date, style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted)
                            Text("Фокус-сессия", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                        }
                        Text("+${session.durationMinutes} мин", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandBlue)
                    }
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun AchievementsContent(sessions: List<com.example.data.FocusSession>) {
    val totalMinutes = sessions.sumOf { it.durationMinutes }
    
    val badges = listOf(
        Pair("Первый шаг", totalMinutes > 0),
        Pair("Новичок (1 ч.)", totalMinutes >= 60),
        Pair("Ученик (5 ч.)", totalMinutes >= 300),
        Pair("Мастер (10 ч.)", totalMinutes >= 600),
        Pair("Джедай (24 ч.)", totalMinutes >= 1440),
        Pair("Гений (50 ч.)", totalMinutes >= 3000)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text("Достижения", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark, modifier = Modifier.padding(top=16.dp))
        
        val unlockedCount = badges.count { it.second }
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandAccentYellow.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = null, tint = com.example.ui.theme.BrandAccentYellow, modifier = Modifier.size(48.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Открыто наград", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted)
                    Text("$unlockedCount из ${badges.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                }
            }
        }

        badges.chunked(2).forEach { rowBadges ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                rowBadges.forEach { badge ->
                    Card(
                        modifier = Modifier.weight(1f).aspectRatio(1f),
                        colors = CardDefaults.cardColors(containerColor = if (badge.second) com.example.ui.theme.BrandSurface else com.example.ui.theme.BrandSurface.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.Star, 
                                contentDescription = null, 
                                tint = if (badge.second) com.example.ui.theme.BrandAccentYellow else com.example.ui.theme.BrandTextMuted.copy(alpha=0.3f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                badge.first, 
                                style = MaterialTheme.typography.bodyMedium, 
                                fontWeight = FontWeight.Bold, 
                                color = if (badge.second) com.example.ui.theme.BrandTextDark else com.example.ui.theme.BrandTextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                if (rowBadges.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun ProfileContent(onGoToSettings: () -> Unit, sessions: List<com.example.data.FocusSession>) {
    val totalMinutes = sessions.sumOf { it.durationMinutes }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text("Профиль", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark, modifier = Modifier.padding(top=16.dp))
        
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
                contentDescription = "Avatar",
                modifier = Modifier.size(100.dp).clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(16.dp))
            Text("Ученик", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
            Text("Фокус: $totalMinutes мин", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.BrandTextMuted)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.BrandSurface),
            shape = RoundedCornerShape(20.dp),
            onClick = onGoToSettings
        ) {
            Row(
                modifier = Modifier.padding(20.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = com.example.ui.theme.BrandBlue)
                    Spacer(Modifier.width(16.dp))
                    Text("Настройки PIN и темы", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = com.example.ui.theme.BrandTextDark)
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = com.example.ui.theme.BrandTextMuted)
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}
