package com.example.logic

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.FocusLockService
import com.example.data.AppSettings
import com.example.data.SettingsRepository
import com.example.data.FocusSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class FocusUiState {
    object Splash : FocusUiState()
    object Setup : FocusUiState()
    object Locked : FocusUiState()
    object SetupPIN : FocusUiState()
}

class FocusViewModel(private val repository: SettingsRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<FocusUiState>(FocusUiState.Splash)
    val uiState: StateFlow<FocusUiState> = _uiState.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(0)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _pinError = MutableStateFlow<String?>(null)
    val pinError: StateFlow<String?> = _pinError.asStateFlow()

    val settings: StateFlow<AppSettings?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)


    val sessions = repository.sessions
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    private var timerJob: Job? = null


    private var appContext: Context? = null

    fun setAppContext(context: Context) {
        this.appContext = context.applicationContext
    }

    private fun playUnlockSound(context: Context) {
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            val mediaPlayer = android.media.MediaPlayer.create(context, uri)
            mediaPlayer?.setOnCompletionListener {
                it.release()
            }
            mediaPlayer?.start()
            
            kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                kotlinx.coroutines.delay(5000)
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer.stop()
                }
                mediaPlayer?.release()
            }
        } catch (e: Exception) {}
    }

    init {
        viewModelScope.launch {
            val initialSettings = repository.getSettingsDirect()
            if (initialSettings != null && initialSettings.isLocked) {
                val now = System.currentTimeMillis()
                val endTime = initialSettings.lockEndTimeMillis
                val calculatedRemaining = if (endTime > now) ((endTime - now) / 1000).toInt() else 0

                // If calculated remaining is valid, use it; otherwise fallback to saved remainingSeconds (prevents reboot clock hacks)
                val effectiveRemaining = if (calculatedRemaining > 0 && calculatedRemaining <= initialSettings.lockDurationSeconds) {
                    calculatedRemaining
                } else if (initialSettings.remainingSeconds > 0) {
                    initialSettings.remainingSeconds
                } else {
                    0
                }

                if (effectiveRemaining > 0) {
                    val newEndTime = now + effectiveRemaining * 1000L
                    repository.saveSettings(
                        initialSettings.copy(
                            isLocked = true,
                            remainingSeconds = effectiveRemaining,
                            lockEndTimeMillis = newEndTime
                        )
                    )
                    _remainingSeconds.value = effectiveRemaining
                    _uiState.value = FocusUiState.Locked
                    startTimer(effectiveRemaining)
                } else {
                    // Time expired
                    repository.saveSettings(
                        initialSettings.copy(
                            isLocked = false,
                            remainingSeconds = 0,
                            lockEndTimeMillis = 0L
                        )
                    )
                    delay(1500)
                    _uiState.value = FocusUiState.Setup
                }
            } else {
                delay(1500) // Показываем заставку 1.5 секунды
                _uiState.value = FocusUiState.Setup
            }
        }
    }

    fun cancelSetupPin() {
        _uiState.value = FocusUiState.Setup
    }

    fun startFocus(durationMinutes: Int, context: Context? = null) {
        viewModelScope.launch {
            val totalSeconds = durationMinutes * 60
            val endTimeMillis = System.currentTimeMillis() + totalSeconds * 1000L
            
            val current = repository.getSettingsDirect() ?: AppSettings()
            repository.saveSettings(
                current.copy(
                    isLocked = true,
                    lockDurationSeconds = totalSeconds,
                    remainingSeconds = totalSeconds,
                    lockEndTimeMillis = endTimeMillis
                )
            )

            _remainingSeconds.value = totalSeconds
            _uiState.value = FocusUiState.Locked
            
            context?.let {
                try {
                    FocusLockService.start(it, totalSeconds)
                } catch (e: Exception) {}
            }
            
            startTimer(totalSeconds)
        }
    }

    private fun startTimer(initialSeconds: Int) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var seconds = initialSeconds
            var saveCounter = 0
            while (seconds > 0) {
                _remainingSeconds.value = seconds
                delay(1000)
                seconds--
                saveCounter++
                
                // Periodically persist remaining time to SQLite database
                if (saveCounter >= 5 || seconds <= 5) {
                    saveCounter = 0
                    val current = repository.getSettingsDirect()
                    if (current != null && current.isLocked) {
                        repository.saveSettings(current.copy(remainingSeconds = seconds))
                    }
                }
            }
            _remainingSeconds.value = 0
            stopFocus(null, isNaturalExpiration = true)
        }
    }

    fun stopFocus(context: Context? = null, isNaturalExpiration: Boolean = false) {
        timerJob?.cancel()
        viewModelScope.launch {
            val current = repository.getSettingsDirect() ?: AppSettings()
            
            if (isNaturalExpiration) {
                val durationMins = current.lockDurationSeconds / 60
                if (durationMins > 0) {
                    repository.insertSession(FocusSession(durationMinutes = durationMins, timestampMillis = System.currentTimeMillis()))
                }
            }
            
            repository.saveSettings(
                current.copy(
                    isLocked = false,
                    remainingSeconds = 0,
                    lockEndTimeMillis = 0L
                )
            )
        }
        val safeContext = context?.applicationContext ?: appContext
        safeContext?.let {
            try {
                FocusLockService.stop(it)
                if (isNaturalExpiration) {
                    playUnlockSound(it)
                }
            } catch (e: Exception) {}
        }
        _uiState.value = FocusUiState.Setup
        _pinError.value = null
    }

    fun verifyPinAndUnlock(inputPin: String, context: Context? = null) {
        viewModelScope.launch {
            val currentSettings = repository.getSettingsDirect() ?: settings.value
            if (currentSettings?.pin == inputPin) {
                stopFocus(context)
            } else {
                _pinError.value = "Неверный PIN-код"
            }
        }
    }

    fun clearPinError() {
        _pinError.value = null
    }

    fun savePin(pin: String, securityAnswer: String) {
        viewModelScope.launch {
            val current = repository.getSettingsDirect() ?: settings.value ?: AppSettings()
            repository.saveSettings(current.copy(pin = pin, securityAnswer = securityAnswer))
            _uiState.value = FocusUiState.Setup
        }
    }

    fun verifySecurityAnswer(answer: String, context: Context? = null, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val currentSettings = repository.getSettingsDirect() ?: settings.value
            if (currentSettings != null && currentSettings.securityAnswer.equals(answer.trim(), ignoreCase = true)) {
                repository.saveSettings(currentSettings.copy(
                    pin = "",
                    securityAnswer = "",
                    isLocked = false,
                    remainingSeconds = 0,
                    lockEndTimeMillis = 0L
                ))
                context?.let {
                    try {
                        FocusLockService.stop(it)
                    } catch (e: Exception) {}
                }
                _uiState.value = FocusUiState.Setup
                _pinError.value = null
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }
    
    fun setTheme(isDark: Boolean?) {
        viewModelScope.launch {
            val current = repository.getSettingsDirect() ?: settings.value ?: AppSettings()
            repository.saveSettings(current.copy(isDarkTheme = isDark))
        }
    }
    
    fun goToSetupPin() {
        _uiState.value = FocusUiState.SetupPIN
    }
}

