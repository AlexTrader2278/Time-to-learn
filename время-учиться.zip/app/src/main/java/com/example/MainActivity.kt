package com.example

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.SettingsRepository
import com.example.logic.FocusUiState
import com.example.logic.FocusViewModel
import com.example.ui.FocusLockApp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private lateinit var viewModel: FocusViewModel

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        try {
            if (::viewModel.isInitialized && viewModel.uiState.value is FocusUiState.Locked) {
                val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                activityManager.moveTaskToFront(taskId, 0)
            }
        } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        try {
            if (::viewModel.isInitialized && viewModel.uiState.value is FocusUiState.Locked) {
                startLockTask()
                FocusLockService.start(this, viewModel.remainingSeconds.value)
            }
        } catch (e: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        try {
            if (!hasFocus && ::viewModel.isInitialized && viewModel.uiState.value is FocusUiState.Locked) {
                val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                activityManager.moveTaskToFront(taskId, 0)
            }
        } catch (e: Exception) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE app_settings ADD COLUMN lockEndTimeMillis INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE app_settings ADD COLUMN isLocked INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE app_settings ADD COLUMN lockDurationSeconds INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE app_settings ADD COLUMN remainingSeconds INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE app_settings ADD COLUMN securityAnswer TEXT NOT NULL DEFAULT ''")
            }
        }


        val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `focus_sessions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `durationMinutes` INTEGER NOT NULL, `timestampMillis` INTEGER NOT NULL)")
            }
        }
        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "focus-lock-db"
        ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
        .fallbackToDestructiveMigration()
        .build()

        val repository = SettingsRepository(db.settingsDao())
        
        viewModel = androidx.lifecycle.ViewModelProvider(this, object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return FocusViewModel(repository) as T
            }
        })[FocusViewModel::class.java]
        
        viewModel.setAppContext(this)

        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsState()
            val isDarkTheme = settings?.isDarkTheme ?: isSystemInDarkTheme()
            
            MyApplicationTheme(darkTheme = isDarkTheme) {
                FocusLockApp(viewModel)
            }
        }
    }
}


