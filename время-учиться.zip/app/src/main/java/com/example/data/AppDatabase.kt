package com.example.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [AppSettings::class, FocusSession::class], version = 5, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun settingsDao(): SettingsDao
}
