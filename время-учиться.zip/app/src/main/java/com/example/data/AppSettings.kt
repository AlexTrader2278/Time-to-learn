package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 0,
    val pin: String = "",
    val securityAnswer: String = "",
    val defaultDurationMinutes: Int = 30,
    val isDarkTheme: Boolean? = null, // null means system default
    val isLocked: Boolean = false,
    val lockDurationSeconds: Int = 0,
    val remainingSeconds: Int = 0,
    val lockEndTimeMillis: Long = 0L
)
