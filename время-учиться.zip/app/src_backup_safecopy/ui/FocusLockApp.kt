package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.MainActivity
import com.example.logic.FocusUiState
import com.example.logic.FocusViewModel

@Composable
fun FocusLockApp(viewModel: FocusViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val activity = LocalActivity.current ?: return

    val context = androidx.compose.ui.platform.LocalContext.current
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        AnimatedContent(
            targetState = uiState,
            transitionSpec = {
                fadeIn(animationSpec = tween(500)) togetherWith fadeOut(animationSpec = tween(500))
            },
            label = "ScreenTransition"
        ) { state ->
            when (state) {
                is FocusUiState.Splash -> SplashScreen()
                is FocusUiState.Setup -> SetupScreen(
                    onStart = { duration -> viewModel.startFocus(duration, context) },
                    onGoToSettings = { viewModel.goToSetupPin() },
                    hasPin = !settings?.pin.isNullOrEmpty()
                )
                is FocusUiState.Locked -> LockedScreen(
                    viewModel = viewModel,
                    onUnlockRequested = { pin -> viewModel.verifyPinAndUnlock(pin, context) }
                )
                is FocusUiState.SetupPIN -> SettingsScreen(
                    currentPin = settings?.pin,
                    currentThemeIsDark = settings?.isDarkTheme,
                    onSavePin = { pin, answer -> viewModel.savePin(pin, answer) },
                    onThemeChange = { isDark -> viewModel.setTheme(isDark) },
                    onCancel = { viewModel.cancelSetupPin() }
                )
            }
        }
    }
}

@Composable
fun SplashScreen() {
    val alpha = remember { Animatable(0f) }
    
    LaunchedEffect(Unit) {
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(1000, easing = LinearOutSlowInEasing)
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "SplashAnimation")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScaleAnimation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(alpha = alpha.value),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
                contentDescription = null,
                modifier = Modifier
                    .size(240.dp)
                    .graphicsLayer(scaleX = scale, scaleY = scale)
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Время Учиться",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 2.sp
                )
            )
        }
    }
}

@Composable
fun SetupScreen(onStart: (Int) -> Unit, onGoToSettings: () -> Unit, hasPin: Boolean) {
    var selectedDuration by remember { mutableStateOf(30) }
    val durations = listOf(15, 30, 60, 90)
    
    val context = LocalContext.current
    val hasOverlayPermission = android.provider.Settings.canDrawOverlays(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Spacer(modifier = Modifier.height(48.dp))
        
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
            contentDescription = null,
            modifier = Modifier.size(140.dp)
        )

        Text(
            text = "Время Учиться",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )

        if (!hasOverlayPermission) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Внимание!", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                    Text("Чтобы блокировка не сбрасывалась при перезагрузке устройства, необходимо дать разрешение.", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onErrorContainer, contentColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Text("Разрешить")
                    }
                }
            }
        }

        Text(
            text = "Выберите время блокировки",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            durations.forEach { duration ->
                FilterChip(
                    selected = selectedDuration == duration,
                    onClick = { selectedDuration = duration },
                    label = { Text("$duration мин") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        OutlinedTextField(
            value = if (selectedDuration == 0) "" else selectedDuration.toString(),
            onValueChange = { 
                val newValue = it.toIntOrNull() ?: 0
                selectedDuration = newValue.coerceIn(0, 1440)
            },
            label = { Text("Своё время (мин, до 24 ч)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        Button(
            onClick = { onStart(selectedDuration) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = hasPin && selectedDuration > 0,
            shape = MaterialTheme.shapes.medium
        ) {
            Text("Начать блокировку", style = MaterialTheme.typography.titleMedium)
        }

        if (!hasPin) {
            Text(
                text = "Сначала установите PIN-код в настройках",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        IconButton(onClick = onGoToSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Настройки")
        }
    }
}

@Composable
fun LockedScreen(viewModel: FocusViewModel, onUnlockRequested: (String) -> Unit) {
    val activity = LocalActivity.current
    val window = activity?.window
    
    LaunchedEffect(Unit) {
        try {
            activity?.startLockTask()
        } catch (e: Exception) {}
        
        window?.let {
            WindowCompat.setDecorFitsSystemWindows(it, false)
            WindowInsetsControllerCompat(it, it.decorView).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }
    
    DisposableEffect(Unit) {
        onDispose {
            try {
                activity?.stopLockTask()
            } catch (e: Exception) {}
            
            window?.let {
                WindowCompat.setDecorFitsSystemWindows(it, true)
                WindowInsetsControllerCompat(it, it.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    BackHandler(enabled = true) {
        // Запрещаем выход кнопкой "Назад"
    }
    
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val pinError by viewModel.pinError.collectAsState()
    
    var showUnlockDialog by remember { mutableStateOf(false) }
    var showForgotPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val timeStr = String.format("%02d:%02d", minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.marusya_logo_1781247831439),
            contentDescription = null,
            modifier = Modifier.size(120.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = timeStr,
            style = MaterialTheme.typography.displayLarge.copy(
                fontWeight = FontWeight.Black,
                fontSize = 80.sp
            )
        )

        Text(
            text = "Время учиться!",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        )

        Text(
            text = "Study Mode Active",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(64.dp))

        OutlinedButton(
            onClick = { 
                viewModel.clearPinError()
                showUnlockDialog = true 
            },
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.medium
        ) {
            Text("Досрочно разблокировать")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = { showForgotPinDialog = true }) {
            Text("Забыли PIN-код?", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (showForgotPinDialog) {
        var answerInput by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf("") }
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showForgotPinDialog = false },
            title = { Text("Восстановление доступа") },
            text = {
                Column {
                    Text("Введите секретное кодовое слово, заданное при создании PIN-кода:")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = answerInput,
                        onValueChange = { answerInput = it; errorMsg = "" },
                        isError = errorMsg.isNotEmpty(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (errorMsg.isNotEmpty()) {
                        Text(errorMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.verifySecurityAnswer(answerInput, context) { success ->
                        if (success) {
                            showForgotPinDialog = false
                        } else {
                            errorMsg = "Неверное кодовое слово"
                        }
                    }
                }) { Text("Сбросить PIN") }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPinDialog = false }) { Text("Отмена") }
            }
        )
    }

    if (showUnlockDialog) {
        AlertDialog(
            onDismissRequest = { 
                showUnlockDialog = false 
                pinInput = ""
                viewModel.clearPinError()
            },
            title = { Text("Введите PIN-код") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { 
                            pinInput = it 
                            if (pinError != null) viewModel.clearPinError()
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        isError = pinError != null,
                        placeholder = { Text("PIN") }
                    )
                    if (pinError != null) {
                        Text(
                            text = pinError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { 
                    onUnlockRequested(pinInput)
                }) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showUnlockDialog = false
                    pinInput = ""
                    viewModel.clearPinError()
                }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
fun SettingsScreen(
    currentPin: String?, 
    currentThemeIsDark: Boolean?, 
    onSavePin: (String, String) -> Unit, 
    onThemeChange: (Boolean?) -> Unit, 
    onCancel: () -> Unit
) {
    BackHandler {
        onCancel()
    }
    
    var oldPin by remember { mutableStateOf("") }
    var pin1 by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    
    val needsOldPin = !currentPin.isNullOrEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(24.dp))
        
        // Theme section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Оформление", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = currentThemeIsDark == null,
                        onClick = { onThemeChange(null) },
                        label = { Text("Системная") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = currentThemeIsDark == false,
                        onClick = { onThemeChange(false) },
                        label = { Text("Светлая") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = currentThemeIsDark == true,
                        onClick = { onThemeChange(true) },
                        label = { Text("Темная") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Text("PIN-код (безопасность)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        
        if (needsOldPin) {
            OutlinedTextField(
                value = oldPin,
                onValueChange = { 
                    oldPin = it
                    error = "" 
                },
                label = { Text("Текущий PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        OutlinedTextField(
            value = pin1,
            onValueChange = { 
                pin1 = it
                error = "" 
            },
            label = { Text(if (needsOldPin) "Новый PIN" else "PIN-код") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = pin2,
            onValueChange = { 
                pin2 = it
                error = "" 
            },
            label = { Text("Повторите PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = answer,
            onValueChange = {
                answer = it
                error = ""
            },
            label = { Text("Кодовое слово (для сброса)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (error.isNotEmpty()) {
            Text(
                error, 
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f)
            ) {
                Text(if (pin1.isEmpty() && pin2.isEmpty()) "Назад" else "Отмена")
            }
            
            Button(
                onClick = {
                    if (pin1.isEmpty() && pin2.isEmpty() && oldPin.isEmpty()) {
                        // User might just be changing theme, allowing empty save to just exit if not changing pin
                        if (!needsOldPin || currentPin.isNullOrEmpty()) {
                            onCancel()
                        } else {
                            onCancel()
                        }
                    } else if (needsOldPin && oldPin != currentPin) {
                        error = "Неверный текущий PIN-код"
                    } else if (pin1.isNotEmpty() && answer.trim().isEmpty()) {
                        error = "Введите кодовое слово для восстановления"
                    } else if (pin1.length < 4) {
                        error = "PIN должен быть не менее 4 цифр"
                    } else if (pin1 != pin2) {
                        error = "PIN-коды не совпадают"
                    } else {
                        onSavePin(pin1, answer.trim())
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (pin1.isEmpty() && pin2.isEmpty()) "ОК" else "Сохранить PIN")
            }
        }
    }
}
