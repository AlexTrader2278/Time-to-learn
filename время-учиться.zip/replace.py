import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

setup_start = content.find("@Composable\nfun SetupScreen(")
locked_start = content.find("@Composable\nfun LockedScreen(")

with open("/tmp/setup_screen_snippet.kt", "r") as f:
    new_setup = f.read()

new_content = content[:setup_start] + new_setup + "\n" + content[locked_start:]

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(new_content)

