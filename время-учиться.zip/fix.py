import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

# Fix newline in string
content = content.replace('Text("Каждая минута приближает\nк твоей цели."', 'Text("Каждая минута приближает\\nк твоей цели."')
content = content.replace('androidx.compose.material.icons.Icons.Filled.Star', 'Icons.Default.Star')
content = content.replace('androidx.compose.material.icons.Icons.AutoMirrored.Filled.KeyboardArrowRight', 'Icons.AutoMirrored.Filled.KeyboardArrowRight')
content = content.replace('androidx.compose.material.icons.Icons.Filled.Flag', 'Icons.Default.Flag')

# We need to make sure we have the imports!
imports = """import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
"""
if "import androidx.compose.material.icons.filled.Star" not in content:
    content = content.replace("import androidx.compose.ui.platform.LocalContext", imports + "import androidx.compose.ui.platform.LocalContext")

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(content)

