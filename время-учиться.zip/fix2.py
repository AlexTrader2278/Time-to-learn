import sys

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

content = content.replace("androidx.compose.foundation.Image", "Image")
content = content.replace("androidx.compose.ui.res.painterResource", "painterResource")
content = content.replace("androidx.compose.foundation.shape.CircleShape", "CircleShape")
content = content.replace("androidx.compose.ui.layout.ContentScale.Crop", "ContentScale.Crop")
content = content.replace("androidx.compose.foundation.shape.RoundedCornerShape", "RoundedCornerShape")
content = content.replace("androidx.compose.material3.CircularProgressIndicator", "CircularProgressIndicator")
content = content.replace("androidx.compose.ui.graphics.Color.Transparent", "Color.Transparent")
content = content.replace("androidx.compose.ui.graphics.StrokeCap.Round", "StrokeCap.Round")
content = content.replace("androidx.compose.ui.draw.clip", "Modifier.clip")

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(content)

