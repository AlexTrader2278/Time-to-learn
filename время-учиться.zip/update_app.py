import sys
import re

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "r") as f:
    content = f.read()

# Replace SetupScreen and LockedScreen with our new logic
# First find imports at the top
setup_idx = content.find("fun SetupScreen(")
settings_idx = content.find("fun SettingsScreen(")

# read new ui
with open("/tmp/new_ui.kt", "r") as f:
    new_ui = f.read()

# Extract just the functions from new_ui
start_setup = new_ui.find("@Composable\nfun SetupScreen")
new_functions = new_ui[start_setup:]

# Add imports
imports_to_add = """
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.systemBarsPadding
"""

content = content[:setup_idx] + new_functions + "\n\n" + content[settings_idx:]
content = content.replace("import androidx.compose.ui.platform.LocalContext", imports_to_add + "import androidx.compose.ui.platform.LocalContext")

with open("app/src/main/java/com/example/ui/FocusLockApp.kt", "w") as f:
    f.write(content)
